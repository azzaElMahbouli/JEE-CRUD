package net.java.management.model;

public class patient {
	private int id;
	private String name;
	private String email;
	private String disease;
	private String phon_number;
	private String rend_vou;
	private String time;
	
	
	public patient(int id, String name, String email, String disease, String phon_number,String rend_vou, String time) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.disease = disease;
		this.phon_number= phon_number;
		this.rend_vou=rend_vou;
		this.time=time;
	}
	
	public patient(String name, String email, String disease,String phon_number,String rend_vou,String time) {
		super();
		this.name = name;
		this.email = email;
		this.disease = disease;
		this.phon_number= phon_number;
		this.rend_vou=rend_vou;
		this.time=time;
		
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDisease() {
		return disease;
	}
	public void setDisease(String disease) {
		this.disease = disease;
	}

	public String getPhon_number() {
		return phon_number;
	}

	public void setPhon_number(String phon_number) {
		this.phon_number = phon_number;
	}

	public String getRend_vou() {
		return rend_vou;
	}

	public void setRend_vou(String rend_vou) {
		this.rend_vou = rend_vou;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}
	
	

}
