package net.java.management.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import net.java.management.model.patient;

// this dao class contient crud operations de la base for the table patients dans la base 

public class PatientDao {
	private String jdbcURL="jdbc:mysql://localhost:3306/demo?user=root&password=root&serverTimezone=Europe/Paris";
	private String jdbcUsername="root";
	private String jdbcPassword="root";
	
	private static final String INSERT_PATIENTS_SQL = "INSERT INTO patients" + "  (name, email, disease,phon_number,rend_vou,time) VALUES "
			+ " (?, ?, ?, ?, ?, ?);";

	private static final String SELECT_PATIENT_BY_ID = "select id,name,email,disease,phon_number,rend_vou,time from patients where id =?";
	private static final String SELECT_ALL_PATIENTS = "select * from patients";
	private static final String DELETE_PATIENTS_SQL = "delete from patients where id = ?";
	private static final String UPDATE_PATIENTS_SQL = "update patients set name = ?,email= ?, disease =?,phon_number=?,rend_vou=?,time=? where id = ?";



	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			 throw new RuntimeException("Error connecting to the database", e);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException("MySQL Driver not found", e);
		}
		return connection;
	}
	
	// create or insert patient
	public void insertPatient(patient patient) throws SQLException {
		try(Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_PATIENTS_SQL)){
			preparedStatement.setString(1,patient.getName());
			preparedStatement.setString(2, patient.getEmail());
			preparedStatement.setString(3, patient.getDisease());
			preparedStatement.setString(4, patient.getPhon_number());
			preparedStatement.setString(5, patient.getRend_vou());
			preparedStatement.setString(6, patient.getTime());
			preparedStatement.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
}
	// update user
	public boolean updatePatient(patient Patient) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(UPDATE_PATIENTS_SQL);) {
			statement.setString(1, Patient.getName());
			statement.setString(2, Patient.getEmail());
			statement.setString(3, Patient.getDisease());
			statement.setString(4, Patient.getPhon_number());
			statement.setString(5, Patient.getRend_vou());
			statement.setString(6, Patient.getTime());
			statement.setInt(7, Patient.getId());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}
	
	// select user by id 
	public patient selectPatient(int id) {
		patient patient = null;
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_PATIENT_BY_ID);) {
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String name = rs.getString("name");
				String email = rs.getString("email");
				String disease = rs.getString("disease");
				String phon_number  = rs.getString("phon_number");
				String rend_vou = rs.getString("rend_vou");
				String time = rs.getString("time");
				patient = new patient(id, name, email, disease,phon_number,rend_vou,time);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return patient;
	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}

	// select All users
	public List<patient> selectAllPatients() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<patient> patients = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_PATIENTS);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String email = rs.getString("email");
				String disease = rs.getString("disease");
				String phon_number  = rs.getString("phon_number");
				String rend_vou = rs.getString("rend_vou");
				String time = rs.getString("time");
				patients.add(new patient(id, name, email, disease,phon_number,rend_vou,time));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return patients;
	}
	// delete user
	public boolean deletePatient(int id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_PATIENTS_SQL);) {
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}


	


}

